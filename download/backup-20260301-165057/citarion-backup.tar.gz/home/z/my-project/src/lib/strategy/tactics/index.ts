/**
 * Tactics Module
 * 
 * Экспорт всех типов и функций для работы с тактиками.
 */

export * from "./types";
export * from "./executor";
